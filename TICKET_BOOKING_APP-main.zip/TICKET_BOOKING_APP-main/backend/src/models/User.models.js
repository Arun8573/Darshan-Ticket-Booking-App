import mongoose from "mongoose";

const UserSchema = mongoose.Schema({
    name:{type:String, required:true, trim:true},
    email:{type:String, required:true, trim:true},
    password:{type:String, required:true, trim:true}
})

const User = mongoose.model('Users',UserSchema)

export default User